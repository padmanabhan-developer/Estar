<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = array(
  0x00 => 'you', 'yang', 'lu', 'si', 'zhi', 'ying', 'du', 'wang', 'hui', 'xie', 'pan', 'shen', 'biao', 'chan', 'mo', 'liu',
  0x10 => 'jian', 'pu', 'se', 'cheng', 'gu', 'bin', 'huo', 'xian', 'lu', 'qin', 'han', 'ying', 'rong', 'li', 'jing', 'xiao',
  0x20 => 'ying', 'sui', 'wei', 'xie', 'huai', 'xue', 'zhu', 'long', 'lai', 'dui', 'fan', 'hu', 'lai', 'shu', 'ling', 'ying',
  0x30 => 'mi', 'ji', 'lian', 'jian', 'ying', 'fen', 'lin', 'yi', 'jian', 'yue', 'chan', 'dai', 'rang', 'jian', 'lan', 'fan',
  0x40 => 'shuang', 'yuan', 'zhuo', 'feng', 'she', 'lei', 'lan', 'cong', 'qu', 'yong', 'qian', 'fa', 'guan', 'que', 'yan', 'hao',
  0x50 => 'ying', 'sa', 'zan', 'luan', 'yan', 'li', 'mi', 'shan', 'tan', 'dang', 'jiao', 'chan', 'ying', 'hao', 'ba', 'zhu',
  0x60 => 'lan', 'lan', 'nang', 'wan', 'luan', 'xun', 'xian', 'yan', 'gan', 'yan', 'yu', 'huo', 'biao', 'mie', 'guang', 'deng',
  0x70 => 'hui', 'xiao', 'xiao', 'hui', 'hong', 'ling', 'zao', 'zhuan', 'jiu', 'zha', 'xie', 'chi', 'zhuo', 'zai', 'zai', 'can',
  0x80 => 'yang', 'qi', 'zhong', 'fen', 'niu', 'jiong', 'wen', 'po', 'yi', 'lu', 'chui', 'pi', 'kai', 'pan', 'yan', 'kai',
  0x90 => 'pang', 'mu', 'chao', 'liao', 'gui', 'kang', 'dun', 'guang', 'xin', 'zhi', 'guang', 'guang', 'wei', 'qiang', 'bian', 'da',
  0xA0 => 'xia', 'zheng', 'zhu', 'ke', 'zhao', 'fu', 'ba', 'xie', 'duo', 'ling', 'zhuo', 'xuan', 'ju', 'tan', 'pao', 'jiong',
  0xB0 => 'pao', 'tai', 'tai', 'bing', 'yang', 'tong', 'han', 'zhu', 'zha', 'dian', 'wei', 'shi', 'lian', 'chi', 'huang', 'zhou',
  0xC0 => 'hu', 'shuo', 'lan', 'ting', 'jiao', 'xu', 'heng', 'quan', 'lie', 'huan', 'yang', 'xiu', 'xiu', 'xian', 'yin', 'wu',
  0xD0 => 'zhou', 'yao', 'shi', 'wei', 'tong', 'mie', 'zai', 'kai', 'hong', 'lao', 'xia', 'zhu', 'xuan', 'zheng', 'po', 'yan',
  0xE0 => 'hui', 'guang', 'che', 'hui', 'kao', 'chen', 'fan', 'shao', 'ye', 'hui', NULL, 'tang', 'jin', 're', 'lie', 'xi',
  0xF0 => 'fu', 'jiong', 'xie', 'pu', 'ting', 'zhuo', 'ting', 'wan', 'hai', 'peng', 'lang', 'yan', 'xu', 'feng', 'chi', 'rong',
);
